﻿const config = {
    clientKey: "",
    host: "https://api.tgsolve.com",

    autorun: true,
    imageclassification: false,
    hcaptcha: false,
    imagetotext: false,
    rainbow: false,
    times: 200,
    isTextCaptcha: false,
    endTimes: "20",
    isAutoClickCheckBox: true,
    checkBoxClickDelayTime: "500",
    isOpenEndTimes: true,
    isOpenCloudflare: false,
    isAutoSubmit: true,
    autoSubmitDelayTime: 100,
    autoSubmitDelayFloatRate: 0.1,
    workStatusFlag: "",
    jsControlObjectName: "tgsolveChorme",
    allowJsInject: false,
    network: {
        hcaptchaVerifyFailDelay: 1000,
        hcaptchaVerifyTry: 3,
        recaptchaVerifyFailDelay: 1000,
        recaptchaVerifyTry: 2,
        funcaptchaVerifyFailDelay: 1000,
        funcaptchaVerifyTry: 3
    },
    funcaptchaConfig: {
        isOpen: true,
        actionAfterRecSuccess: "nothing",
        actionAfterOneRecFail: "nothing",
        actionAfterRecFail: "nothing",
        actionDelay: 6000,
        isAutoClickPrePage: true
    },
    blackListConfig: {
        isOpen: false,
        urlList: []
    },
    whiteListConfig: {
        isOpen: false,
        urlList: []
    },
    awsCaptchaConfig: {
        isOpen: false
    },
    recaptchaConfig: {
        isOpen: false,
        isOpenProtocol: false
    },
    hcaptchaConfig: {
        isAutoRefresh: false
    },
    isHideKey: false
};

chrome.storage.local.get(["config"], function (result) {
    if (result.config) return;
    chrome.storage.local.set({ config });
});

